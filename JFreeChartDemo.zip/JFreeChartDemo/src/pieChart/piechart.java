/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pieChart;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

    /**
     *
     * @author Theeraj Subhakaar AS
     */
public class piechart extends javax.swing.JFrame {

    private DefaultPieDataset pieDataset;
    private JFreeChart pieChart;
    private PiePlot piePlot;
    private ChartPanel ChartPanel;
    public piechart() {
        initComponents();
        showPieChart();
    }
    
    public void showPieChart()
    {
        pieDataset = new DefaultPieDataset();
        pieDataset.setValue("Hi ",new Double(9.0));
        pieDataset.setValue(" Biee",new Double(9.0));
        pieDataset.setValue(" ",new Double(9.0));
        pieDataset.setValue(" ",new Double(9.2));
        pieDataset.setValue(" ",new Double(9.0));
        pieDataset.setValue(" ",new Double(9.2));
        
        pieChart = ChartFactory.createPieChart3D("title", pieDataset,true,true,false);
        
        piePlot = (PiePlot) pieChart.getPlot();
        ChartPanel = new ChartPanel(pieChart);
        pieChartPanel.removeAll();
        pieChartPanel.add(ChartPanel, BorderLayout.CENTER );
        ChartPanel.validate();
        
    }

    private void initComponents() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}