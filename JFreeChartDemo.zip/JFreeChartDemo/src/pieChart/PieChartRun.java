/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pieChart;

/**
 *
 * @author Theeraj Subhakaar AS
 */
public class PieChartRun {
    public static void main(String[] args)
    {
        PieChartJFrame pcjf =new PieChartJFrame();
        pcjf.setVisible(true);
        
    }
}
