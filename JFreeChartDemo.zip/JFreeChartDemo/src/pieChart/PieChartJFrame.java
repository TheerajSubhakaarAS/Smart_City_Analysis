/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pieChart;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

    /**
     *
     * @author Theeraj Subhakaar AS
     */
public class PieChartJFrame extends javax.swing.JFrame {

    private DefaultPieDataset pieDataset;
    private JFreeChart pieChart;
    private PiePlot piePlot;
    private ChartPanel ChartPanel;
    public PieChartJFrame() {
        initComponents();
        showPieChart();
    }
    
    public void showPieChart()
    {
        pieDataset = new DefaultPieDataset();
        pieDataset.setValue("Norway ",new Double(1));
        pieDataset.setValue("Denmark ",new Double(9.0));
        pieDataset.setValue("Canada ",new Double(5.0));
        pieDataset.setValue("Germany ",new Double(9.2));
        pieDataset.setValue("US  ",new Double(9.0));
        pieDataset.setValue("Finland ",new Double(4.2));
        
        pieChart = ChartFactory.createPieChart3D("Smart Government", pieDataset,true,true,false);
        
        piePlot = (PiePlot) pieChart.getPlot();
        ChartPanel = new ChartPanel(pieChart);
        pieChartPanel.removeAll();
        pieChartPanel.add(ChartPanel, BorderLayout.CENTER );
        ChartPanel.validate();
        
    }
    public static void main(String[] args)   
{  
    String clientMessage=" ", serverMessage="";
     
           String file = "C:\\Users\\Theeraj Subhakaar AS\\OneDrive\\Documents\\Smart_City_index_headers.csv";
  String line = " ";
  try {
   BufferedReader reader = new BufferedReader(new FileReader(file));
   while((line = reader.readLine()) != null) {
            
                String[] values=line.split(",");
                System.out.println(values[0]);
                
                
      
        }
   
  }
  catch(Exception e) {
   e.printStackTrace();
  }
  
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        pieChartPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Pie Chart");

        pieChartPanel.setBackground(new java.awt.Color(255, 255, 255));
        pieChartPanel.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(338, 338, 338)
                .addComponent(jLabel1)
                .addContainerGap(344, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pieChartPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(pieChartPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel pieChartPanel;
    // End of variables declaration//GEN-END:variables
}
