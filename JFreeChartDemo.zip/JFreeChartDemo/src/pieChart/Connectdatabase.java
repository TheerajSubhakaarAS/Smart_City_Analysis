/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pieChart;


import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.jdbc.JDBCCategoryDataset;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.*;

public class Connectdatabase {
    
    Statement stmt = null;
    
    
    
    public static void main(String[] args){
        List<Integer> list = new ArrayList<>();
        int temp = 0;
        
        try{
        String  user = "root";
        String password = "2002";
        String url = "jdbc:mysql://localhost:3306/cat";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection c= DriverManager.getConnection(url, user,password);
        if(c!=null){
            System.out.println("Success");
        }
        else{
            System.out.println("Fail");
        }
        java.sql.Statement stmt=c.createStatement();  
        java.sql.ResultSet rs=stmt.executeQuery("SELECT  Id  FROM dataser");   
        while(rs.next()){
            temp = rs.getInt(1);
            list.add(temp);
        /*System.out.println(temp);*/
        }
        
        for (int i=0;i<list.size();i++)
        {
            System.out.println(list.get(i));
        }
        
        c.close();
        
        }
        catch(ClassNotFoundException ex){
            Logger.getLogger(Connectdatabase.class.getName()).log(Level.SEVERE,null,ex);
        } catch (SQLException ex) {
            Logger.getLogger(Connectdatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
         
    }
        
    }
    
