/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pieChart;

import java.util.*;
import java.net.*;
import java.io.*;
public class demo {
    public static void main(String[] args)   
{  
    String clientMessage=" ", serverMessage="";
     
           String file = "C:\\Users\\Theeraj Subhakaar AS\\OneDrive\\Documents\\Smart_City_index_headers.csv";
  String line = " ";
  try {
   BufferedReader reader = new BufferedReader(new FileReader(file));
   while((line = reader.readLine()) != null) {
            
                String[] values=line.split(",");
                System.out.println(values[0]);
                
                
      
        }
   
  }
  catch(Exception e) {
   e.printStackTrace();
  }
  
}
}  